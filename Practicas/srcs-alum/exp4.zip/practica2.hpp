// *********************************************************************
// **
// ** Informática Gráfica, curso 2016-17
// ** Práctica 2  (declaraciones públicas)
// **
// *********************************************************************

#ifndef IG_PRACTICA2_HPP
#define IG_PRACTICA2_HPP

#include "MallaInd.hpp"

void P2_Inicializar( int argc, char *argv[] ) ;
bool P2_FGE_PulsarTeclaNormal(  unsigned char tecla ) ;
void P2_DibujarObjetos( ContextoVis & cv ) ;


#endif
