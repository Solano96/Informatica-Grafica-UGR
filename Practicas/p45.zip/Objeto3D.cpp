#include "Objeto3D.hpp"

std::string Objeto3D::nombre(){
	return nombre_obj;
}
